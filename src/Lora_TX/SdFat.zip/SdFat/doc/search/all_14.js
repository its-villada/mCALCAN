var searchData=
[
  ['validlength_0',['validLength',['../class_ex_fat_file.html#a9b299ba77e9287c74ce08b217a1bff44',1,'ExFatFile']]],
  ['vol_1',['vol',['../class_sd_base.html#a8121e07c8ef606b63d08ba0debfa36f2',1,'SdBase']]],
  ['volumebegin_2',['volumeBegin',['../class_sd_base.html#afa2024973e4e0f327d2e00e00ff5e187',1,'SdBase']]],
  ['volumesectorcount_3',['volumeSectorCount',['../class_fat_partition.html#a916ba7d67711bb62daf12ecd47ca4b8e',1,'FatPartition']]]
];
