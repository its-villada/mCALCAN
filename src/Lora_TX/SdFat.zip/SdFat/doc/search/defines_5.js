var searchData=
[
  ['include_5fsdios_0',['INCLUDE_SDIOS',['../_sd_fat_config_8h.html#a7cc6c9647297d65f8e823de70740630b',1,'SdFatConfig.h']]],
  ['isdirseparator_1',['isDirSeparator',['../_ex_fat_file_8h.html#a9f85580ad6f1dfc86fff09a58ff0a1c0',1,'isDirSeparator():&#160;ExFatFile.h'],['../_fat_file_8h.html#a9f85580ad6f1dfc86fff09a58ff0a1c0',1,'isDirSeparator():&#160;FatFile.h']]]
];
